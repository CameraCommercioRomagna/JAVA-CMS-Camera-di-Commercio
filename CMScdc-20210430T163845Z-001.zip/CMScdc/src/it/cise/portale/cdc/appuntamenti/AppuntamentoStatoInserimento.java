package it.cise.portale.cdc.appuntamenti;

public enum AppuntamentoStatoInserimento {
	OPZIONATO, OPZIONATO_RICHIDENTE, OPZIONATO_PRATICHE, PRENOTATO, ANNULLATO;
}
