package it.cise.portale.cdc.appuntamenti;

public enum TipoUtenzaRilascio {
	NESSUNO, PRIVATO, IMPRESA, PRIVATO_IMPRESA;
}
