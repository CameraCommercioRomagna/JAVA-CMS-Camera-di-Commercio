package it.cise.portale.cdc.documenti;

public enum TipoOrdinamentoDocumenti {
	TEMPORALE, MANUALE;
}
