package it.cise.portale.cdc.documenti;

public enum ForwardBehaviour {
	NO_FORWARD, FORWARD;
}
